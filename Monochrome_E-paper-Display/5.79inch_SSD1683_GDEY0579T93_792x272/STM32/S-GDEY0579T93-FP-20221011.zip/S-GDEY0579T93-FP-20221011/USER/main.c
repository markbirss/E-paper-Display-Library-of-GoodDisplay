#include "stm32f10x.h"
#include "delay.h"
#include "sys.h"
//EPD
#include "Display_EPD_W21_spi.h"
#include "Display_EPD_W21.h"
#include "Ap_29demo.h"	
//GUI
#include "GUI_Paint.h"
#include "fonts.h"


//Tips//
/*
1.When the e-paper is refreshed in full screen, the picture flicker is a normal phenomenon, and the main function is to clear the display afterimage in the previous picture.
2.When the partial refresh is performed, the screen does not flash.
3.After the e-paper is refreshed, you need to put it into sleep mode, please do not delete the sleep command.
4.Please do not take out the electronic paper when power is on.
5.Wake up from sleep, need to re-initialize the e-paper.
6.When you need to transplant the driver, you only need to change the corresponding IO. The BUSY pin is the input mode and the others are the output mode.
*/
int	main(void)
{
	unsigned char fen_L,fen_H,miao_L,miao_H;
		delay_init();	    	     //Delay function initialization
		NVIC_Configuration(); 	//Set NVIC interrupt grouping 2
    EPD_GPIO_Init();       //EPD GPIO  initialization
	while(1)
	{
			
		/************Fast picture display(1.5s)*******************/
    EPD_HW_Init_Fast(); //EPD init Fast
	  EPD_WhiteScreen_ALL_Fast(gImage_1);//EPD_picture1
		EPD_DeepSleep();//EPD_DeepSleep,Sleep instruction is necessary, please do not delete!!!
		delay_s(2); //2s  
    EPD_HW_Init_Fast(); //EPD init Fast
	  EPD_WhiteScreen_ALL_Fast(gImage_2);//EPD_picture1
		EPD_DeepSleep();//EPD_DeepSleep,Sleep instruction is necessary, please do not delete!!!
		delay_s(2); //2s  		
	  EPD_HW_Init_Fast(); //EPD init Fast
	  EPD_WhiteScreen_ALL_Fast(gImage_3);//EPD_picture1
		EPD_DeepSleep();//EPD_DeepSleep,Sleep instruction is necessary, please do not delete!!!
		delay_s(2); //2s  	  
//////////////////////Partial refresh time demo/////////////////////////////////////		
		EPD_HW_Init(); //Electronic paper initialization
    EPD_SetRAMValue_BaseMap(gImage_basemap);
	  EPD_HW_Init_Part();

		for(fen_H=0;fen_H<6;fen_H++)
		{
		for(fen_L=0;fen_L<10;fen_L++)
		{
		for(miao_H=0;miao_H<6;miao_H++) 	
		{
		for(miao_L=0;miao_L<10;miao_L++)
		{
				EPD_Dis_Part_myself_S(64,80,Num1[fen_H],         //x-A,y-A,DATA-A
														64+48,80,Num1[fen_L],         //x-B,y-B,DATA-B
			                      64+48*2,80,gImage_dot1,       //x-C,y-C,DATA-C
														64+48*3,80,Num1[miao_H],       //x-D,y-D,DATA-D
														64+48*4,80,Num1[miao_L],104,48);	 //x-D,y-D,DATA-D,Resolution 32*64												
														if((fen_L==0)&&(miao_H==0)&&(miao_L==5))
														goto Clear;  
			 } 
		  }
		 }	
		}	
		
		Clear:
		delay_s(1); //1s	
		EPD_HW_Init(); //Electronic paper initialization
		EPD_WhiteScreen_White(); //Show all white
		EPD_DeepSleep(); //Enter deep sleep,Sleep instruction is necessary, please do not delete!!!
	  delay_s(2); //2s				
    while(1);
 
		

	}
}	


