#include "stm32f10x.h"
#include "delay.h"
#include "sys.h"
//EPD
#include "Display_EPD_W21_spi.h"
#include "Display_EPD_W21.h"
#include "Ap_29demo.h"	
//GUI
#include "GUI_Paint.h"
#include "fonts.h"


//Tips//
/*
1.When the e-paper is refreshed in full screen, the picture flicker is a normal phenomenon, and the main function is to clear the display afterimage in the previous picture.
2.When the partial refresh is performed, the screen does not flash.
3.After the e-paper is refreshed, you need to put it into sleep mode, please do not delete the sleep command.
4.Please do not take out the electronic paper when power is on.
5.Wake up from sleep, need to re-initialize the e-paper.
6.When you need to transplant the driver, you only need to change the corresponding IO. The BUSY pin is the input mode and the others are the output mode.
*/
int	main(void)
{
		delay_init();	    	     //Delay function initialization
		NVIC_Configuration(); 	//Set NVIC interrupt grouping 2
    EPD_GPIO_Init();       //EPD GPIO  initialization
	while(1)
	{	
		//ALl display
    EPD_init(); //EPD init
	  PIC_display(gImage_2);//EPD_picture1
		EPD_sleep();//EPD_sleep,Sleep instruction is necessary, please do not delete!!!
		delay_s(3); //3s	
  ///////////////////////////Quick refresh picture display/////////////////////////////////////////////////////////////////
		/************Quick refresh picture display*******************/
    EPD_init_Fast(); //EPD init
	  PIC_display(gImage_5);//EPD_picture1
		EPD_sleep();//EPD_sleep,Sleep instruction is necessary, please do not delete!!!
		delay_s(1); //2s		
    EPD_init_Fast(); //EPD init
	  PIC_display(gImage_6);//EPD_picture1
		EPD_sleep();//EPD_sleep,Sleep instruction is necessary, please do not delete!!!
		delay_s(1); //2s	
    EPD_init_Fast(); //EPD init
	  PIC_display(gImage_7);//EPD_picture1
		EPD_sleep();//EPD_sleep,Sleep instruction is necessary, please do not delete!!!
		delay_s(3); //3s	
		
		/************Partial refresh picture display*******************/
		EPD_init_Fast(); //EPD init
		PIC_display(gImage_basemap);//EPD_picture1
		EPD_Part_Init(); //EPD part init			
		EPD_Dis_Part(0,0,gImage_2,320,240,0); //partial display 1
		delay_s(1); //1s	
		EPD_Part_Init(); //EPD part init		
		EPD_Dis_Part(0,0,gImage_5,320,240,1); //partial display 2
		delay_s(1); //1s	 
		EPD_Part_Init(); //EPD part init				
		EPD_Dis_Part(0,0,gImage_6,320,240,1); //partial display 3 
		delay_s(1); //1s
		EPD_Part_Init(); //EPD part init			
		EPD_Dis_Part(0,0,gImage_7,320,240,1); //partial display 4
		delay_s(1); //1s	
		EPD_Part_Init(); //EPD part init		
		EPD_Dis_Part(0,0,gImage_8,320,240,1); //partial display 5
		delay_s(3); //3s  
		
//Clear		
		EPD_init(); //EPD init
		PIC_display_Clear();//EPD Clear
		EPD_sleep();//EPD_sleep,Sleep instruction is necessary, please do not delete!!!	
		while(1);  

	}
}	


