#include "Display_EPD_W21_spi.h"
#include "Display_EPD_W21.h"


unsigned char oldData[15000];
void delay_xms(unsigned int xms)
{
	unsigned int i;
	while(xms--)
	{
		i=12000;
		while(i--);
	}
}

void EPD_W21_Init(void)
{
	unsigned char i;
	for(i=0;i<3;i++)
	{
		EPD_W21_RST_0;		// Module reset
		delay_xms(10);//At least 10ms delay 
		EPD_W21_RST_1;
		delay_xms(10);//At least 10ms delay 
	}

}

void EPD_Display(unsigned char *Image)
{
    unsigned int Width, Height,i,j;
    Width = (EPD_WIDTH % 8 == 0)? (EPD_WIDTH / 8 ): (EPD_WIDTH / 8 + 1);
    Height = EPD_HEIGHT;
	
    EPD_W21_WriteCMD(0x10);
    for (j = 0; j < Height; j++) {
        for ( i = 0; i < Width; i++) {
            EPD_W21_WriteDATA(0x00);
        }
    }

    EPD_W21_WriteCMD(0x13);
    for ( j = 0; j < Height; j++) {
        for ( i = 0; i < Width; i++) {
           EPD_W21_WriteDATA(Image[i + j * Width]);
        }
    }
		//Refresh and Sleep
		EPD_refresh();//EPD Refresh

}

void EPD_lut()			
{
		unsigned char tempfull,temppartial;
		EPD_W21_WriteCMD(0x40);
		lcd_chkstatus();
		tempfull = EPD_W21_ReadDATA();
		if((128>tempfull)&&(tempfull>54))		
			tempfull = 53 ;						
		else if(tempfull>128)					
			tempfull = 1;							
		temppartial = tempfull+60;				
		if(temppartial>128)						
			temppartial = 127;
	
		EPD_W21_WriteCMD(0xe0);
		EPD_W21_WriteDATA (0x02);
		EPD_W21_WriteCMD(0xe5);
		EPD_W21_WriteDATA (temppartial); 	
}

//UC8176
void EPD_init(void)
{	
		EPD_W21_Init(); //Electronic paper IC reset
	
		EPD_W21_WriteCMD(0x06);         //boost soft start
		EPD_W21_WriteDATA (0x17);		//A
		EPD_W21_WriteDATA (0x17);		//B
		EPD_W21_WriteDATA (0x17);		//C        
	
		EPD_W21_WriteCMD(0x04);  
		lcd_chkstatus();//waiting for the electronic paper IC to release the idle signal

		EPD_W21_WriteCMD(0x00);			//panel setting
		EPD_W21_WriteDATA(0x1f);		//LUT from OTP��KW-BF   KWR-AF	BWROTP 0f	BWOTP 1f

		EPD_W21_WriteCMD(0x61);			//resolution setting
		EPD_W21_WriteDATA (0x01); 
		EPD_W21_WriteDATA (0x90);    //400	 
		EPD_W21_WriteDATA (0x01);		//300
		EPD_W21_WriteDATA (0x2c);	
	
		EPD_W21_WriteCMD(0X50);			//VCOM AND DATA INTERVAL SETTING			
		EPD_W21_WriteDATA(0x97);		//WBmode:VBDF 17|D7 VBDW 97 VBDB 57		WBRmode:VBDF F7 VBDW 77 VBDB 37  VBDR B7
    
		
}
void EPD_init_Fast(void)
{	
		EPD_W21_Init(); //Electronic paper IC reset
	
		EPD_W21_WriteCMD(0x06);         //boost soft start
		EPD_W21_WriteDATA (0x17);		//A
		EPD_W21_WriteDATA (0x17);		//B
		EPD_W21_WriteDATA (0x17);		//C        
	
		EPD_W21_WriteCMD(0x04);  
		lcd_chkstatus();//waiting for the electronic paper IC to release the idle signal

		EPD_W21_WriteCMD(0x00);			//panel setting
		EPD_W21_WriteDATA(0x1f);		//LUT from OTP��KW-BF   KWR-AF	BWROTP 0f	BWOTP 1f

		EPD_W21_WriteCMD(0x61);			//resolution setting
		EPD_W21_WriteDATA (0x01); 
		EPD_W21_WriteDATA (0x90);    //400	 
		EPD_W21_WriteDATA (0x01);		//300
		EPD_W21_WriteDATA (0x2c);	
	
		EPD_W21_WriteCMD(0X50);			//VCOM AND DATA INTERVAL SETTING			
		EPD_W21_WriteDATA(0x97);		//WBmode:VBDF 17|D7 VBDW 97 VBDB 57		WBRmode:VBDF F7 VBDW 77 VBDB 37  VBDR B7

		EPD_W21_WriteCMD(0xE0);				
		EPD_W21_WriteDATA(0x02);		
		EPD_W21_WriteCMD(0xE5);			
		EPD_W21_WriteDATA(0x4B);		

	  EPD_W21_WriteCMD(0x82);			//vcom_DC setting  	
    EPD_W21_WriteDATA (0x12);	
}



//UC8276
void EPD_init_Partial(void)
{
		EPD_W21_Init(); //Electronic paper IC reset
	
		EPD_W21_WriteCMD(0x06);         //boost soft start
		EPD_W21_WriteDATA (0x17);		//A
		EPD_W21_WriteDATA (0x17);		//B
		EPD_W21_WriteDATA (0x17);		//C        
	
		EPD_W21_WriteCMD(0x04);  
		lcd_chkstatus();//waiting for the electronic paper IC to release the idle signal

		EPD_W21_WriteCMD(0x00);			//panel setting
		EPD_W21_WriteDATA(0x1f);		//LUT from OTP��KW-BF   KWR-AF	BWROTP 0f	BWOTP 1f

		EPD_W21_WriteCMD(0x61);			//resolution setting
		EPD_W21_WriteDATA (0x01); 
		EPD_W21_WriteDATA (0x90);    //400	 
		EPD_W21_WriteDATA (0x01);		//300
		EPD_W21_WriteDATA (0x2c);	
	
		EPD_W21_WriteCMD(0xE0);				
		EPD_W21_WriteDATA(0x02);		
		EPD_W21_WriteCMD(0xE5);			
		EPD_W21_WriteDATA(0x5A);		
		EPD_W21_WriteCMD(0X50);			//VCOM AND DATA INTERVAL SETTING			
		EPD_W21_WriteDATA(0x07);		//WBmode:VBDF 17|D7 VBDW 97 VBDB 57		WBRmode:VBDF F7 VBDW 77 VBDB 37  VBDR B7



}	


	
void EPD_sleep(void)
{
		EPD_W21_WriteCMD(0X50);  //VCOM AND DATA INTERVAL SETTING			
		EPD_W21_WriteDATA(0xf7); //WBmode:VBDF 17|D7 VBDW 97 VBDB 57		WBRmode:VBDF F7 VBDW 77 VBDB 37  VBDR B7	

		EPD_W21_WriteCMD(0X02);  	//power off
	  lcd_chkstatus();          //waiting for the electronic paper IC to release the idle signal
		delay_xms(100);
	  EPD_W21_WriteCMD(0X07);  	//deep sleep
		EPD_W21_WriteDATA(0xA5);
}



void PIC_display(const unsigned char* picData)
{
    unsigned int i;
		EPD_W21_WriteCMD(0x10);	       //Transfer old data
	  for(i=0;i<15000;i++)	  
    {	
	  EPD_W21_WriteDATA(0xff); 
    }	
		EPD_W21_WriteCMD(0x13);		     //Transfer new data
	  for(i=0;i<15000;i++)	     
	  {
	  EPD_W21_WriteDATA(*picData);  //Transfer the actual displayed data
	  picData++;
	  }
		//Refresh and Sleep
		EPD_refresh();//EPD Refresh

}
void PIC_display_Clear(void)
{
    unsigned int i;
		EPD_W21_WriteCMD(0x10);	       //Transfer old data
	  for(i=0;i<15000;i++)	  
    {	
	  EPD_W21_WriteDATA(0xFF); 
    }
		EPD_W21_WriteCMD(0x13);		     //Transfer new data
	  for(i=0;i<15000;i++)	     
	  {
	  EPD_W21_WriteDATA(0xFF);  //Transfer the actual displayed data
	  }
		//Refresh and Sleep
		EPD_refresh();//EPD Refresh
		

}
void EPD_refresh(void)
{
		EPD_W21_WriteCMD(0x12);		//DISPLAY REFRESH 	
		delay_xms(1);	             //!!!The delay here is necessary, 200uS at least!!!     
		lcd_chkstatus();          //waiting for the electronic paper IC to release the idle signal
}

  

void lcd_chkstatus(void)
{
	while(!isEPD_W21_BUSY);                         
}

void EPD_Dis_Part(unsigned int x_start,unsigned int y_start,const unsigned char * new_data,unsigned int PART_COLUMN,unsigned int PART_LINE,unsigned char mode) //mode 0: first  1: other...
{
unsigned int datas,i;
unsigned int x_end,y_end;
	
	
	x_end=x_start+PART_LINE-1; 
	x_end=400-x_end;
	x_start=400-x_start;
	
	y_end=y_start+PART_COLUMN-1; 	
	datas=PART_LINE*PART_COLUMN/8;

	  EPD_init_Partial();
			
	  EPD_W21_WriteCMD(0x91);		//This command makes the display enter partial mode
		EPD_W21_WriteCMD(0x90);		//resolution setting
		EPD_W21_WriteDATA (x_end/256);
		EPD_W21_WriteDATA (x_end%256);   //x-start    
		
		EPD_W21_WriteDATA (x_start/256);		
		EPD_W21_WriteDATA (x_start%256-1);  //x-end

		EPD_W21_WriteDATA (y_start/256);
		EPD_W21_WriteDATA (y_start%256);   //y-start    
		
		EPD_W21_WriteDATA (y_end/256);		
		EPD_W21_WriteDATA (y_end%256-1);  //y-end
		EPD_W21_WriteDATA (0x2b);

		EPD_W21_WriteCMD(0x10);	       //writes Old data to SRAM for programming
		for(i=0;i<datas;i++)	     
		 {
			 if(mode==0)
			EPD_W21_WriteDATA(0x00); 
       else
 			EPD_W21_WriteDATA(~oldData[i]); 	 
		 }  
 
		EPD_W21_WriteCMD(0x13);				 //writes New data to SRAM.
		for(i=0;i<datas;i++)	     
	 {
		EPD_W21_WriteDATA(~new_data[i]);
    oldData[i]=new_data[i]; 			 
	 } 
		//Refresh 
		EPD_refresh();//EPD Refresh
	  
}













/***********************************************************
						end file
***********************************************************/

