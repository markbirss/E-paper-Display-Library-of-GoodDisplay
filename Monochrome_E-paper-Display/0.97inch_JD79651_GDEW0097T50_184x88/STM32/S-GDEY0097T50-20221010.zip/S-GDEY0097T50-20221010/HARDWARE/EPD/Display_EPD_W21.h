#ifndef _DISPLAY_EPD_W21_H_
#define _DISPLAY_EPD_W21_H_


#define EPD_WIDTH   88
#define EPD_HEIGHT  184

//EPD
void EPD_W21_Init(void);
void EPD_init(void);
void PIC_display (const unsigned char* picData);
void EPD_sleep(void);
void EPD_refresh(void);
void lcd_chkstatus(void);
void PIC_display_Clear(void);
//Display canvas function
void EPD_Display(unsigned char *Image); 
//LUT
void EPD_init_Part(void);
void EPD_Dis_Part(unsigned int x,unsigned int y,const unsigned char * new_data,unsigned int w,unsigned int l,unsigned char mode); //mode 0: first  1: other...

#endif
/***********************************************************
						end file
***********************************************************/


