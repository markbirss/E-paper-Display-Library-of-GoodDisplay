

extern const unsigned char IMAGE_BLACK[];
extern const unsigned char IMAGE_RED[];
extern const unsigned char IMAGE_BLACK1[];


/* FILE END */


