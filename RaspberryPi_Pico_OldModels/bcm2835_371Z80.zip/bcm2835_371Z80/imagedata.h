

extern const unsigned char gImage_black1[];
extern const unsigned char gImage_red1[];

/* FILE END */


