

extern const unsigned char IMAGE_BLACK[];
extern const unsigned char IMAGE_RED[];
extern const unsigned char IMAGE_BLACK1[];
extern const unsigned char IMAGE_RED1[];
extern const unsigned char IMAGE_BLACK2[];
extern const unsigned char IMAGE_RED2[];

/* FILE END */


