

extern const unsigned char gImage_BW[];
extern const unsigned char gImage_R[];



/* FILE END */


