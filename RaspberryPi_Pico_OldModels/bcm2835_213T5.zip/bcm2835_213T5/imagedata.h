

extern const unsigned char IMAGE_BLACK[];
extern const unsigned char IMAGE_RED[];

/* FILE END */


