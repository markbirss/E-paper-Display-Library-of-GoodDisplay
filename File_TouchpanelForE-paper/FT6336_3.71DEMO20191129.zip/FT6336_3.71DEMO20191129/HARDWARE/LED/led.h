#ifndef __LED_H
#define __LED_H	 
#include "sys.h"
							  
////////////////////////////////////////////////////////////////////////////////// 
#define LED0 PEout(12)// PE12	

void LED_Init(void);//��ʼ��

		 				    
#endif
