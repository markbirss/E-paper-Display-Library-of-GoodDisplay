#include "Display_EPD_W21_spi.h"
#include "Display_EPD_W21.h"

void delay_xms(unsigned int xms)
{
	unsigned int i;
	while(xms--)
	{
		i=12000;
		while(i--);
	}
}

void EPD_W21_Init(void)
{
	EPD_W21_RST_0;		// Module reset
	delay_xms(10);//At least 10ms delay 
	EPD_W21_RST_1;
	delay_xms(10);//At least 10ms delay 
	
}

void EPD_init(void)
{	

		EPD_W21_Init();	//Electronic paper IC reset		
	
		EPD_W21_WriteCMD(0x01);    //POWER SETTING
		EPD_W21_WriteDATA (0x37);	   
		EPD_W21_WriteDATA (0x00);
		EPD_W21_WriteDATA (0x23);
		EPD_W21_WriteDATA (0x23);
	
		EPD_W21_WriteCMD(0X00);			//PANNEL SETTING
		EPD_W21_WriteDATA(0xEF);
		EPD_W21_WriteDATA(0x08);

		EPD_W21_WriteCMD(0x03);			//PFS
		EPD_W21_WriteDATA (0x00);   

		EPD_W21_WriteCMD(0x06);         //boost�趨
		EPD_W21_WriteDATA (0xC7);	   	
		EPD_W21_WriteDATA (0xC7);
		EPD_W21_WriteDATA (0x1D);

	
		EPD_W21_WriteCMD(0x30);			//PLL setting
		EPD_W21_WriteDATA (0x3C);   //PLL:    0-25��:0x3C,25+:0x3A   
	
		EPD_W21_WriteCMD(0X41);			//TSE
		EPD_W21_WriteDATA(0x00);
	
		EPD_W21_WriteCMD(0X50);			//VCOM AND DATA INTERVAL SETTING
		EPD_W21_WriteDATA(0x37); //0x77

		EPD_W21_WriteCMD(0X60);			//TCON SETTING
		EPD_W21_WriteDATA(0x22);

		EPD_W21_WriteCMD(0X60);			//TCON SETTING
		EPD_W21_WriteDATA(0x22);

		EPD_W21_WriteCMD(0x61);        	//tres			
		EPD_W21_WriteDATA (0x02);		//source 600
		EPD_W21_WriteDATA (0x58);
		EPD_W21_WriteDATA (0x01);		//gate 448
		EPD_W21_WriteDATA (0xC0);

		EPD_W21_WriteCMD(0xE3);			//PWS	   	
		EPD_W21_WriteDATA(0xAA);	

		EPD_W21_WriteCMD(0x04);			//PWR on 	
		lcd_chkstatus();          //waiting for the electronic paper IC to release the idle signal
}
	
void EPD_sleep(void)
{
    EPD_W21_WriteCMD(0X02);  	//power off
	  lcd_chkstatus();          //waiting for the electronic paper IC to release the idle signal
		EPD_W21_WriteCMD(0X07);  	//deep sleep
		EPD_W21_WriteDATA(0xA5);
}

/**********************************display picture**********************************/	
void Acep_color(unsigned char color)
{
  unsigned int i,j;
	EPD_W21_WriteCMD(0x10);	       
  for(i=0;i<448;i++)
	{
    for(j=0;j<300;j++)
		{
      EPD_W21_WriteDATA(color);
		}
  }
	
	//Refresh
	EPD_W21_WriteCMD(0x12);		//DISPLAY REFRESH 	
	delay_xms(1);	             //!!!The delay here is necessary, 200uS at least!!!     
	lcd_chkstatus();          //waiting for the electronic paper IC to release the idle signal

}
/*
White  	///	001--0XFF
Yellow  ///	101--0XFC
Orange  ///	110--0XEC
Red     ///	100--0XE0
Green   ///	010--0X35
Blue   	///	011--0X2B
Black   /// 000--0X00

//0XFF,0XFC,0XEC,0XE0,0X35,0X2B,0X00
*/
unsigned char Color_get(unsigned char color)
{
	unsigned datas;
	switch(color)
	{
		case 0xFF:
			datas=white;
		break;
		case 0xFC:
			datas=yellow;
		break;	
		case 0xEC:
			datas=orange;
		break;			
		case 0xE0:
			datas=red;
		break;	
		case 0x35:
			datas=green;
		break;	
		case 0x2B:
			datas=blue;
		break;	
		case 0x00:
			datas=black;
		break;		
    default:
    break;			
	}
	 return datas;
}
void PIC_display(const unsigned char* picData)
{
  unsigned int i,j,k;
	unsigned char temp1,temp2;
	unsigned char data_H,data_L,data;
	

	Acep_color(Clean); //Each refresh must be cleaned first	
	EPD_W21_WriteCMD(0x10);	       
  for(i=0;i<448;i++)
	{ 
		k=0;
    for(j=0;j<300;j++)
		{
		  
			temp1=picData[i*600+k++]; 
			temp2=picData[i*600+k++];
			data_H=Color_get(temp1)<<4;
			data_L=Color_get(temp2);
			data=data_H|data_L;
      EPD_W21_WriteDATA(data);
		}
  }	
	
	 //Refresh
	  EPD_W21_WriteCMD(0x12);		//DISPLAY REFRESH 	
		delay_xms(1);	  //!!!The delay here is necessary, 200uS at least!!!     
		lcd_chkstatus();          //waiting for the electronic paper IC to release the idle signal

}


void EPD_horizontal(void)
{
  unsigned int i,j;
  unsigned char index = 0x00;
  unsigned char const Color[8] = {Black,White,Green,Blue,Red,Yellow,Orange,Clean};

 Acep_color(Clean); //Each refresh must be cleaned first	  
	EPD_W21_WriteCMD(0x10);	     //start to transport picture
  for(i=0;i<448;i++){
    if((i%56 == 0) && (i != 0))
      index ++;
    for(j =0;j<600/2;j++){
      EPD_W21_WriteDATA(Color[index]);
    }
  }
	 //Refresh
	  EPD_W21_WriteCMD(0x12);		//DISPLAY REFRESH 	
		delay_xms(1);	  //!!!The delay here is necessary, 200uS at least!!!     
		lcd_chkstatus();          //waiting for the electronic paper IC to release the idle signal

}
void EPD_vertical(void)
{
  unsigned int i,j,k;
  unsigned char const Color[8] = {Black,White,Green,Blue,Red,Yellow,Orange,Clean};
	
  Acep_color(Clean); //Each refresh must be cleaned first	
	EPD_W21_WriteCMD(0x10);	     //start to transport pictu
  for(i=0;i<448;i++)
	{
    for(k = 0 ; k < 7; k ++)  //7 color
		{
      for(j = 0 ; j < 38; j ++)
			{
        EPD_W21_WriteDATA(Color[k]);
      }
    }
    for(j = 0; j <34 ; j++) 
		{
      EPD_W21_WriteDATA(0x77);
    }
  }
	 //Refresh
	  EPD_W21_WriteCMD(0x12);		//DISPLAY REFRESH 	
		delay_xms(1);	  //!!!The delay here is necessary, 200uS at least!!!     
		lcd_chkstatus();          //waiting for the electronic paper IC to release the idle signal

}

void PIC_display_Clear(void)
{
   unsigned int i,j;
	Acep_color(Clean); //Each refresh must be cleaned first	
	EPD_W21_WriteCMD(0x10);	       
  for(i=0;i<448;i++)
	{
    for(j=0;j<300;j++)
		{
      EPD_W21_WriteDATA(White);
		}
  }
	
	//Refresh
	EPD_W21_WriteCMD(0x12);		//DISPLAY REFRESH 	
	delay_xms(1);	             //!!!The delay here is necessary, 200uS at least!!!     
	lcd_chkstatus();          //waiting for the electronic paper IC to release the idle signal

}

void lcd_chkstatus(void)
{
	while(!isEPD_W21_BUSY);                         
}














/***********************************************************
						end file
***********************************************************/

